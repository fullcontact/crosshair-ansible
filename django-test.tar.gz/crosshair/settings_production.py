from crosshair.settings import *  # noqa

DEBUG = False
